// AUTO GENERATED MACRO DEFINITIONS FOR G3LOG

/** ==========================================================================
* 2015 by KjellKod.cc. This is PUBLIC DOMAIN to use at your own risk and comes
* with no warranties. This code is yours to share, use and modify with no
* strings attached and no restrictions or obligations.
*
* For more information see g3log/LICENSE or refer refer to http://unlicense.org
* ============================================================================*/
#pragma once

// CMake induced definitions below. See g3log/Options.cmake for details.

#define G3_DYNAMIC_LOGGING 1
#define DISABLE_FATAL_SIGNALHANDLING 1
//#define CHANGE_G3LOG_DEBUG_TO_DBUG 1
