#pragma once
#include <string>
#include <iostream>
#include <mlclient/ext/g3log/logmessage.hpp>

struct G3OutSink {

  void ReceiveLogMessage(g3::LogMessageMover logEntry) {
     auto level = logEntry.get()._level;

     std::cout << logEntry.get().toString() << std::endl;
  }
};
